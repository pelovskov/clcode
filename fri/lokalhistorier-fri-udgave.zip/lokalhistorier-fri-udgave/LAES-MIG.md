# Lokalhistorier · fri udgave

Mappen er en fri udgave af byggerne og værktøjerne. Den er til enkeltpersoner, skoleklasser, ungdomsskolen og andre institutioner, som vil lave deres egne historier, album, lydfortællinger og meget mere.

Start med at åbne **`index.html`**. Den er forsiden med links til det hele.

## Hvad er forskellen fra foreningernes byggere?

Den frie udgave er lavet ud fra de samme byggere, som foreningerne i den fælles portal bruger, med disse forskelle:

- **Udgiveren skriver man selv,** fx "7.b, Roskilde Lille Skole" eller sit eget navn. Der er ingen liste over foreninger.
- **Der er tre farvetemaer,** Vinter (blå), Sommer (grøn) og Hindbær (rød), alle med lys og mørk tilstand.
- **Identifikatoren har intet foreningspræfiks,** fx `album-sommerlejren-2026`.
- **Emneordene er dem, man selv skriver.** Udgiveren sættes ikke ind som første emneord, og de fælles emneord er ikke et krav. Siden `emneord.html` giver forslag: foreningernes fælles emneord uden dem, der kun gælder Roskilde.
- **Foreningernes særlige ting er fjernet,** fx Sidebyggerens faste serier og foreningernes farver.

Filformatet er det samme. En fil fra den frie udgave kan derfor åbnes i foreningernes byggere og omvendt. Den får så det andet sted standardtemaet.

## Indhold

| Hvad | Fil |
|---|---|
| Forside | `index.html` |
| Sidebygger, Album, Enkeltbillede, Før og Nu, Bog, Lydfortælling, Mediekort, Præsentation, Vejledning | `…-bygger.html` |
| Samling · Bygger, som binder 2–6 filer sammen | `samling-bygger.html` |
| Søgeside · Bygger, som laver en søgeside til en mappe | `soegeside-bygger.html` |
| Feltoptager, Lydlab, Fotolab og Skyggeramme | `feltoptager.html`, `lydlab.html`, `fotolab.html`, `skyggeramme.html` |
| Huskesedler til Side, Album, Lydfortælling, Præsentation, Bog, Mediekort og Samling med Søgeside | `vejledning-….html` |
| Forslag til emneord, med en kopiér-knap ved hvert ord | `emneord.html` |
| Må det komme med? Tjek af samtykke til billeder, lyd og tekst, med øvelser og samtykkesedler | `maa-det-komme-med.html` |
| QR-kode til skilte og ark, med titel og tekst, laves på din egen computer | `qr-kode.html` |

Hele mappen kan kopieres til et USB-stik eller lægges på en hjemmeside. Alt virker uden internet.

Søgeside · Bygger og de færdige søgesider har knappen **Gem det hele som zip-fil**. Den samler søgesiden og dens filer i én zip-fil. På en søgeside bliver du bedt om at vælge den mappe, hvor søgesiden ligger.

Ligger mappen på en hjemmeside, viser forsiden knappen **Hent det hele som zip-fil**. Den henter `lokalhistorier-fri-udgave.zip` med forsiden, byggerne, værktøjerne og denne vejledning. Pak zip-filen ud, og åbn `index.html`. I en udpakket kopi er knappen skjult, fordi zip-filen ikke ligger i den.

## Til den, der vedligeholder

Byggerne i mappen laves af opskriften **`lav-fri-udgave.py`** ud fra de almindelige byggere i repoets rod og værktøjerne i `tools/`, også `emneord.html` ud fra `tools/emneord.html`. Ret aldrig i de lavede filer i hånden. Ret i den almindelige bygger eller i opskriften, og kør opskriften igen:

```
python3 fri/lav-fri-udgave.py
```

Kun `index.html`, `LAES-MIG.md` og huskesedlerne `vejledning-….html` er skrevet i hånden. Manuskripterne til screencasts ligger i repoets mappe `vejledninger/`. Til sidst pakker opskriften det hele i `lokalhistorier-fri-udgave.zip`. Zip-filen ændrer sig kun, når indholdet gør. Opskriften stopper med en fejlbesked, hvis en almindelig bygger er ændret, så den ikke længere passer. Så skal opskriften rettes til.
